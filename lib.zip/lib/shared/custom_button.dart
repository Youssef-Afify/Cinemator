import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:task/core/constants/app_colors.dart';
import 'package:task/shared/custom_text.dart';

class CustomButton extends StatefulWidget {
  final String text;
  final void Function()? onTap;
  final double? width;
  final double? height;
  final double? radius;

  final bool isLoading;

  const CustomButton({
    super.key,
    required this.text,
    this.onTap,
    this.width,
    this.height,
    this.radius,
    this.isLoading = false,
  });

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.isLoading ? null : widget.onTap,
      child: Container(
        width: widget.width ?? 150,
        height: widget.height ?? 50,
        decoration: BoxDecoration(
          color: AppColors.primary,
          borderRadius: BorderRadius.circular(widget.radius ?? 15),
        ),
        child: Center(
          child: widget.isLoading
              ? LoadingAnimationWidget.horizontalRotatingDots(
                  color: Colors.white,
                  size: 24,
                )
              : CustomText(widget.text, color: Colors.white, size: 18),
        ),
      ),
    );
  }
}
