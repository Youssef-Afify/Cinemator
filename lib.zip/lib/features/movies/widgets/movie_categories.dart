import 'package:flutter/material.dart';
import 'package:task/core/constants/app_colors.dart';

class MovieCategories extends StatefulWidget {
  const MovieCategories({super.key, required this.categories});
  final List<String> categories;

  @override
  State<MovieCategories> createState() => _MovieCategoriesState();
}

class _MovieCategoriesState extends State<MovieCategories> {
  late List<String> _categories;
  int selectedCategory = 0;

  @override
  void initState() {
    _categories = widget.categories;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(_categories.length, (index) {
          return GestureDetector(
            onTap: () => setState(() => selectedCategory = index),
            child: Container(
              margin: index == 0 ? null : EdgeInsets.only(left: 15),
              padding: EdgeInsets.symmetric(horizontal: 27, vertical: 12),
              decoration: BoxDecoration(
                color: selectedCategory == index
                    ? AppColors.primary
                    : AppColors.neutral,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                _categories[index],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: selectedCategory == index
                      ? Colors.white
                      : Colors.black,
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
