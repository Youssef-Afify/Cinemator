// Expanded(
                    //   child: GridView.builder(
                    //     gridDelegate:
                    //         const SliverGridDelegateWithFixedCrossAxisCount(
                    //           crossAxisCount: 2,
                    //           childAspectRatio: 0.7,
                    //           crossAxisSpacing: 8,
                    //           mainAxisSpacing: 8,
                    //         ),
                    //     itemCount: provider.movies.length,
                    //     itemBuilder: (context, index) {
                    //       final movie = provider.movies[index];
                    //       return CustomMovieCard(movie: movie);
                    //     },
                    //   ),
                    // ),
                    // Padding(
                    //   padding: const EdgeInsets.symmetric(
                    //     horizontal: 16,
                    //     vertical: 12,
                    //   ),
                    //   child: Row(
                    //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //     children: [
                    //       ElevatedButton(
                    //         onPressed: _currentPage > 1
                    //             ? () => _goToPage(_currentPage - 1)
                    //             : null,
                    //         child: const Text('Previous'),
                    //       ),
                    //       Text('Page $_currentPage of ${provider.totalPages}'),
                    //       ElevatedButton(
                    //         onPressed: provider.hasMorePages
                    //             ? () => _goToPage(_currentPage + 1)
                    //             : null,
                    //         child: const Text('Next'),
                    //       ),
                    //     ],
                    //   ),
                    // ),