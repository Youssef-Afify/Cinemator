import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task/core/constants/app_colors.dart';
import 'package:task/features/movies/data/cast_model.dart';
import 'package:task/features/movies/data/movie_details_model.dart';
import 'package:task/features/movies/data/video_model.dart';
import 'package:task/features/movies/provider/favorites_provider.dart';
import 'package:task/features/movies/provider/tmdb_provider.dart';

class MovieDetailsView extends StatefulWidget {
  final int movieId;

  const MovieDetailsView({super.key, required this.movieId});

  @override
  State<MovieDetailsView> createState() => _MovieDetailsViewState();
}

class _MovieDetailsViewState extends State<MovieDetailsView> {
  // A saturated pink distinct from the app's blush accent (0xffE9BCB6),
  // chosen so white chip text stays legible — swap the hex below if you
  // have a specific shade from your design system in mind.
  static const _chipPink = Color(0xFFE0577A);

  late final Future<MovieDetailsModel?> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<TmdbProvider>().getMovieDetails(widget.movieId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: FutureBuilder<MovieDetailsModel?>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(color: AppColors.primary),
            );
          }

          final movie = snapshot.data;
          if (movie == null) {
            return _ErrorState(onBack: () => Navigator.of(context).pop());
          }

          return CustomScrollView(
            slivers: [
              _BackdropHeader(movie: movie),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        movie.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 10),
                      _MetaRow(movie: movie),
                      if ((movie.genres ?? []).isNotEmpty) ...[
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: movie.genres!
                              .map((g) => _GenreChip(
                                    name: g.name,
                                    color: _chipPink,
                                  ))
                              .toList(),
                        ),
                      ],
                      const SizedBox(height: 24),
                      Consumer<FavoritesProvider>(
                        builder: (context, favoritesProvider, child) {
                          final isFavorite =
                              favoritesProvider.isFavorite(movie.id);
                          return SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () =>
                                  favoritesProvider.toggleFavorite(movie),
                              icon: Icon(
                                isFavorite
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: Colors.white,
                              ),
                              label: Text(
                                isFavorite
                                    ? 'Added to Favorites'
                                    : 'Add to Favorites',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      if ((movie.overview ?? '').isNotEmpty) ...[
                        const SizedBox(height: 32),
                        const _SectionTitle('Synopsis'),
                        const SizedBox(height: 10),
                        Text(
                          movie.overview!,
                          style: TextStyle(
                            color: AppColors.neutral,
                            fontSize: 14,
                            height: 1.5,
                          ),
                        ),
                      ],
                      if ((movie.cast ?? []).isNotEmpty) ...[
                        const SizedBox(height: 32),
                        const _SectionTitle('Top Cast'),
                        const SizedBox(height: 14),
                        SizedBox(
                          height: 96,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: movie.cast!.length > 12
                                ? 12
                                : movie.cast!.length,
                            separatorBuilder: (_, _) =>
                                const SizedBox(width: 16),
                            itemBuilder: (context, index) =>
                                _CastTile(cast: movie.cast![index]),
                          ),
                        ),
                      ],
                      if (movie.trailer != null) ...[
                        const SizedBox(height: 32),
                        const _SectionTitle('Trailers & More'),
                        const SizedBox(height: 14),
                        _TrailerCard(video: movie.trailer!),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _BackdropHeader extends StatelessWidget {
  final MovieDetailsModel movie;

  const _BackdropHeader({required this.movie});

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: AspectRatio(
        aspectRatio: 16 / 10,
        child: Stack(
          fit: StackFit.expand,
          children: [
            movie.backdropPath != null
                ? Image.network(
                    movie.backdropUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) =>
                        Container(color: const Color(0xFF1A1A1A)),
                  )
                : Container(color: const Color(0xFF1A1A1A)),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.1),
                    AppColors.bg,
                  ],
                  stops: const [0.4, 1.0],
                ),
              ),
            ),
            Positioned(
              top: 8,
              left: 8,
              child: SafeArea(
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.5),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: SafeArea(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        size: 16,
                        color: Color(0xFFFFC940),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        movie.formattedRating,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetaRow extends StatelessWidget {
  final MovieDetailsModel movie;

  const _MetaRow({required this.movie});

  @override
  Widget build(BuildContext context) {
    final dotStyle = TextStyle(color: AppColors.neutral);
    final textStyle =
        TextStyle(color: AppColors.neutral, fontWeight: FontWeight.w600);

    final children = <Widget>[
      Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, size: 16, color: Color(0xFFFFC940)),
          const SizedBox(width: 4),
          Text(movie.formattedRating, style: textStyle),
        ],
      ),
      Text('•', style: dotStyle),
      Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(movie.releaseYear, style: textStyle),
          if (movie.adult) ...[
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 5,
                vertical: 1,
              ),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                '+18',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ],
      ),
    ];

    if (movie.formattedRuntime.isNotEmpty) {
      children.add(Text('•', style: dotStyle));
      children.add(Text(movie.formattedRuntime, style: textStyle));
    }

    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      children: children,
    );
  }
}

class _GenreChip extends StatelessWidget {
  final String name;
  final Color color;

  const _GenreChip({required this.name, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        name,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _CastTile extends StatelessWidget {
  final CastModel cast;

  const _CastTile({required this.cast});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 72,
      child: Column(
        children: [
          CircleAvatar(
            radius: 32,
            backgroundColor: const Color(0xFF2A2A2A),
            backgroundImage:
                cast.profilePath != null ? NetworkImage(cast.profileUrl) : null,
            child: cast.profilePath == null
                ? const Icon(Icons.person, color: Colors.white38)
                : null,
          ),
          const SizedBox(height: 6),
          Text(
            cast.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrailerCard extends StatelessWidget {
  final VideoModel video;

  const _TrailerCard({required this.video});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.network(
              video.thumbnailUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) =>
                  Container(color: const Color(0xFF1A1A1A)),
            ),
            DecoratedBox(
              decoration:
                  BoxDecoration(color: Colors.black.withValues(alpha: 0.25)),
            ),
            Center(
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.55),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.play_arrow_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
            Positioned(
              left: 12,
              bottom: 10,
              right: 12,
              child: Text(
                video.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  shadows: [Shadow(blurRadius: 6, color: Colors.black)],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;

  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.w800,
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final VoidCallback onBack;

  const _ErrorState({required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, color: Colors.white54, size: 40),
          const SizedBox(height: 12),
          const Text(
            'Could not load movie details',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 16),
          TextButton(onPressed: onBack, child: const Text('Go back')),
        ],
      ),
    );
  }
}