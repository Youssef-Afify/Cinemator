import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class SearchField extends StatefulWidget {
  final TextEditingController? controller;
  final ValueChanged<String> onSearch;
  final ValueChanged<bool> onFavorite;
  const SearchField({
    super.key,
    this.controller,
    required this.onSearch,
    required this.onFavorite,
  });

  @override
  State<SearchField> createState() => _SearchFieldState();
}

class _SearchFieldState extends State<SearchField> {
  bool favorite = false;

  @override
  Widget build(BuildContext context) {
    InputBorder border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: BorderSide(color: Colors.white),
    );
    return Material(
      elevation: 3,
      shadowColor: Colors.grey,
      borderRadius: BorderRadius.circular(15),
      child: TextField(
        controller: widget.controller,
        onChanged: (value) => widget.onSearch(value),
        cursorColor: AppColors.primary,
        cursorHeight: 20.0,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          prefixIcon: Icon(Icons.search),
          hintText: 'Search...',
          enabledBorder: border,
          disabledBorder: border,
          focusedBorder: border,
          suffixIcon: GestureDetector(
            onTap: () {
              setState(() => favorite = !favorite);
              widget.onFavorite(favorite);
            },
            child: Icon(
              favorite ? Icons.favorite : Icons.favorite_border,
              color: Colors.red[800],
            ),
          ),
        ),
      ),
    );
  }
}
