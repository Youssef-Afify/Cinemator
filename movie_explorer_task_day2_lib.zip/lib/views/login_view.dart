import 'package:flutter/material.dart';
import 'package:task/shared/material_page_route.dart';
import 'package:task/views/home_view.dart';
import 'package:task/widgets/custom_app_bar.dart';
import 'package:task/widgets/custom_button.dart';

class LoginView extends StatelessWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('Login'),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Welcome to Movie Explorer Application!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 20),
            CustomButton(
              text: 'Enter App',
              onTap: () =>
                  Navigator.of(context).pushReplacement(route(HomeView())),
            ),
          ],
        ),
      ),
    );
  }
}
