import 'package:flutter/material.dart';
import 'package:task/widgets/custom_app_bar.dart';

class MovieDetails extends StatelessWidget {
  final String name;
  final String genre;
  final String release;
  const MovieDetails({
    super.key,
    required this.name,
    required this.genre,
    required this.release,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('Movie Details'),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Center(
          child: Column(
            children: [
              Text(name, style: TextStyle(color: Colors.black, fontSize: 22)),
              Text('$genre - $release', style: TextStyle(color: Colors.black, fontSize: 12)),
            ]
          )
        )
      ),
    );
  }
}
