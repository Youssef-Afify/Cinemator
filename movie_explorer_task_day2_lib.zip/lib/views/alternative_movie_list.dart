import 'package:flutter/material.dart';
import 'package:task/views/movie_details.dart';
import 'package:task/widgets/custom_app_bar.dart';
import 'package:task/widgets/custom_movie_tile.dart';

class AlternativeMovieList extends StatelessWidget {
  const AlternativeMovieList({super.key});

  @override
  Widget build(BuildContext context) {
    List<Map<String, String>> movies = [
      {'name': 'Inception', 'genre': 'Science Fiction', 'release': '2010'},
      {'name': 'Interstellar', 'genre': 'Science Fiction', 'release': '2014'},
      {'name': 'The Dark Knight', 'genre': 'Superhero', 'release': '2008'},
      {'name': 'Avatar', 'genre': 'Science Fiction', 'release': '2009'},
      {'name': 'The Matrix', 'genre': 'Science Fiction', 'release': '1999'},
      {'name': 'Gladiator', 'genre': 'History', 'release': '2000'},
    ];
    return Scaffold(
      appBar: customAppBar('Alternative Movies'),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView.separated(
          separatorBuilder: (context, index) => Divider(),
          itemCount: movies.length,
          itemBuilder: (context, index) => Column(
            children: [
              SizedBox(height: 5),
              CustomMovieTile(
                name: movies[index]['name']!,
                genre: movies[index]['genre']!,
                release: movies[index]['release']!,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => MovieDetails(
                      name: movies[index]['name']!,
                      genre: movies[index]['genre']!,
                      release: movies[index]['release']!,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 5),
            ],
          ),
        ),
      ),
    );
  }
}
