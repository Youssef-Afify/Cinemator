import 'package:flutter/material.dart';

class CustomMovieTile extends StatelessWidget {
  final String name;
  final String genre;
  final String release;
  final void Function()? onTap;
  const CustomMovieTile({
    super.key,
    required this.name,
    required this.genre,
    required this.release,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        alignment: AlignmentGeometry.centerStart,
        padding: EdgeInsets.all(16),
        width: double.infinity,
        height: 90,
        decoration: BoxDecoration(
          color: Colors.blue,
          border: BoxBorder.all(
            color: Colors.blue[900]!,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: TextStyle(color: Colors.white, fontSize: 22)),
                Text('$genre - $release', style: TextStyle(color: Colors.white, fontSize: 12)),
              ],
            ),
            Icon(Icons.arrow_right, size: 50, color: Colors.white),
          ],
        ),
      ),
    );
  }
}
