import 'package:flutter/material.dart';
import 'package:task/constants/app_colors.dart';

AppBar customAppBar(String title) {
  return AppBar(
    foregroundColor: Colors.white,
    backgroundColor: AppColors.primary,
    centerTitle: true,
    title: Text(title),
  );
}
