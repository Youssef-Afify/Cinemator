import 'package:flutter/material.dart';
import 'package:task/views/genres_view.dart';
import 'package:task/views/login_view.dart';
import 'package:task/views/movies_view.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const LoginView(),
      routes: {'/genres': (_) => GenresView(), '/movies': (_) => MoviesView()},
    );
  }
}
